﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FARMACIA_GALERAS_2
{
    public partial class Domicilios : Form
    {
        validacionn v = new validacionn();
        public Domicilios()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtNombreProducto_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.sololetras(e);
        }

        private void txtCódigoProducto_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }

        private void txtValorUnitario_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }

        private void txtValorTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }

        private void btnConfirmarDomi_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ocultar el formulario activo
                         // Mostrar Form1
            Usuario_domicilio frm = new Usuario_domicilio();
            frm.Show();
        }

        private void btnCancelarDomi_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ocultar el formulario activo
                         // Mostrar Form1
            MenúOpciones frm = new MenúOpciones();
            frm.Show();
        }

        private void Domicilios_Load(object sender, EventArgs e)
        {

        }
    }
}
