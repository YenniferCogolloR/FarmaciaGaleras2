﻿namespace FARMACIA_GALERAS_2
{
    partial class Inventario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inventario));
            this.label1 = new System.Windows.Forms.Label();
            this.lblFechaRealización = new System.Windows.Forms.Label();
            this.txtFechaRea = new System.Windows.Forms.DateTimePicker();
            this.lblNumeroEstante = new System.Windows.Forms.Label();
            this.txtNúmeroEstante = new System.Windows.Forms.NumericUpDown();
            this.lblNombreProducto = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.ComboBox();
            this.lblCódigoProducto = new System.Windows.Forms.Label();
            this.txtCódigoProducto = new System.Windows.Forms.TextBox();
            this.lblCantidadDisponible = new System.Windows.Forms.Label();
            this.lblFechaVencimiento = new System.Windows.Forms.Label();
            this.txtFechaVen = new System.Windows.Forms.DateTimePicker();
            this.lblConcentración = new System.Windows.Forms.Label();
            this.lblPresentación = new System.Windows.Forms.Label();
            this.txtPresentación = new System.Windows.Forms.ComboBox();
            this.btnCancelarInvent = new System.Windows.Forms.Button();
            this.btnConfirmarInvent = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtConcentración = new System.Windows.Forms.CheckedListBox();
            ((System.ComponentModel.ISupportInitialize)(this.txtNúmeroEstante)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(188, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(321, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "INVENTARIOS GALERAS OCCIDENTE  ";
            // 
            // lblFechaRealización
            // 
            this.lblFechaRealización.AutoSize = true;
            this.lblFechaRealización.BackColor = System.Drawing.Color.Silver;
            this.lblFechaRealización.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaRealización.Location = new System.Drawing.Point(12, 55);
            this.lblFechaRealización.Name = "lblFechaRealización";
            this.lblFechaRealización.Size = new System.Drawing.Size(159, 19);
            this.lblFechaRealización.TabIndex = 1;
            this.lblFechaRealización.Text = "Fecha De Realización";
            // 
            // txtFechaRea
            // 
            this.txtFechaRea.CalendarMonthBackground = System.Drawing.Color.White;
            this.txtFechaRea.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtFechaRea.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.txtFechaRea.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFechaRea.Location = new System.Drawing.Point(192, 55);
            this.txtFechaRea.MaxDate = new System.DateTime(2035, 12, 31, 0, 0, 0, 0);
            this.txtFechaRea.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.txtFechaRea.Name = "txtFechaRea";
            this.txtFechaRea.Size = new System.Drawing.Size(257, 25);
            this.txtFechaRea.TabIndex = 2;
            // 
            // lblNumeroEstante
            // 
            this.lblNumeroEstante.AutoSize = true;
            this.lblNumeroEstante.BackColor = System.Drawing.Color.Silver;
            this.lblNumeroEstante.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroEstante.Location = new System.Drawing.Point(455, 55);
            this.lblNumeroEstante.Name = "lblNumeroEstante";
            this.lblNumeroEstante.Size = new System.Drawing.Size(151, 19);
            this.lblNumeroEstante.TabIndex = 3;
            this.lblNumeroEstante.Text = "Número De Estante ";
            // 
            // txtNúmeroEstante
            // 
            this.txtNúmeroEstante.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNúmeroEstante.Location = new System.Drawing.Point(612, 54);
            this.txtNúmeroEstante.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.txtNúmeroEstante.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtNúmeroEstante.Name = "txtNúmeroEstante";
            this.txtNúmeroEstante.Size = new System.Drawing.Size(46, 25);
            this.txtNúmeroEstante.TabIndex = 4;
            this.txtNúmeroEstante.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblNombreProducto
            // 
            this.lblNombreProducto.AutoSize = true;
            this.lblNombreProducto.BackColor = System.Drawing.Color.Silver;
            this.lblNombreProducto.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreProducto.Location = new System.Drawing.Point(30, 99);
            this.lblNombreProducto.Name = "lblNombreProducto";
            this.lblNombreProducto.Size = new System.Drawing.Size(141, 19);
            this.lblNombreProducto.TabIndex = 5;
            this.lblNombreProducto.Text = "Nombre Producto ";
            // 
            // txtNombre
            // 
            this.txtNombre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.txtNombre.Font = new System.Drawing.Font("Berlin Sans FB Demi", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.FormattingEnabled = true;
            this.txtNombre.Location = new System.Drawing.Point(192, 91);
            this.txtNombre.MaxLength = 25;
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(211, 27);
            this.txtNombre.TabIndex = 6;
            this.txtNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombre_KeyPress);
            // 
            // lblCódigoProducto
            // 
            this.lblCódigoProducto.AutoSize = true;
            this.lblCódigoProducto.BackColor = System.Drawing.Color.Silver;
            this.lblCódigoProducto.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCódigoProducto.Location = new System.Drawing.Point(418, 99);
            this.lblCódigoProducto.Name = "lblCódigoProducto";
            this.lblCódigoProducto.Size = new System.Drawing.Size(133, 19);
            this.lblCódigoProducto.TabIndex = 7;
            this.lblCódigoProducto.Text = "Código Producto ";
            // 
            // txtCódigoProducto
            // 
            this.txtCódigoProducto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCódigoProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCódigoProducto.Location = new System.Drawing.Point(557, 92);
            this.txtCódigoProducto.MaxLength = 6;
            this.txtCódigoProducto.Name = "txtCódigoProducto";
            this.txtCódigoProducto.Size = new System.Drawing.Size(101, 26);
            this.txtCódigoProducto.TabIndex = 8;
            this.txtCódigoProducto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcodProduc_KeyPress);
            // 
            // lblCantidadDisponible
            // 
            this.lblCantidadDisponible.AutoSize = true;
            this.lblCantidadDisponible.BackColor = System.Drawing.Color.Silver;
            this.lblCantidadDisponible.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantidadDisponible.Location = new System.Drawing.Point(19, 151);
            this.lblCantidadDisponible.Name = "lblCantidadDisponible";
            this.lblCantidadDisponible.Size = new System.Drawing.Size(152, 19);
            this.lblCantidadDisponible.TabIndex = 9;
            this.lblCantidadDisponible.Text = "Cantidad Disponible";
            // 
            // lblFechaVencimiento
            // 
            this.lblFechaVencimiento.AutoSize = true;
            this.lblFechaVencimiento.BackColor = System.Drawing.Color.Silver;
            this.lblFechaVencimiento.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaVencimiento.Location = new System.Drawing.Point(-1, 195);
            this.lblFechaVencimiento.Name = "lblFechaVencimiento";
            this.lblFechaVencimiento.Size = new System.Drawing.Size(172, 19);
            this.lblFechaVencimiento.TabIndex = 11;
            this.lblFechaVencimiento.Text = "Fecha De Vencimiento ";
            // 
            // txtFechaVen
            // 
            this.txtFechaVen.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtFechaVen.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFechaVen.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtFechaVen.Location = new System.Drawing.Point(192, 191);
            this.txtFechaVen.Name = "txtFechaVen";
            this.txtFechaVen.Size = new System.Drawing.Size(138, 25);
            this.txtFechaVen.TabIndex = 12;
            this.txtFechaVen.Value = new System.DateTime(2022, 3, 1, 8, 59, 35, 0);
            // 
            // lblConcentración
            // 
            this.lblConcentración.AutoSize = true;
            this.lblConcentración.BackColor = System.Drawing.Color.Silver;
            this.lblConcentración.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConcentración.Location = new System.Drawing.Point(60, 283);
            this.lblConcentración.Name = "lblConcentración";
            this.lblConcentración.Size = new System.Drawing.Size(111, 19);
            this.lblConcentración.TabIndex = 15;
            this.lblConcentración.Text = "Concentración";
            // 
            // lblPresentación
            // 
            this.lblPresentación.AutoSize = true;
            this.lblPresentación.BackColor = System.Drawing.Color.Silver;
            this.lblPresentación.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPresentación.Location = new System.Drawing.Point(71, 240);
            this.lblPresentación.Name = "lblPresentación";
            this.lblPresentación.Size = new System.Drawing.Size(100, 19);
            this.lblPresentación.TabIndex = 13;
            this.lblPresentación.Text = "Presentación";
            // 
            // txtPresentación
            // 
            this.txtPresentación.AutoCompleteCustomSource.AddRange(new string[] {
            "Capsulas",
            "Comprimidos",
            "Solubles",
            "Stick pack",
            "Jarabes",
            "Ampollas "});
            this.txtPresentación.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtPresentación.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPresentación.Items.AddRange(new object[] {
            "Capsulas",
            "Comprimidos",
            "Solubles",
            "Stick pack",
            "Jarabes",
            "Ampollas "});
            this.txtPresentación.Location = new System.Drawing.Point(192, 237);
            this.txtPresentación.Name = "txtPresentación";
            this.txtPresentación.Size = new System.Drawing.Size(121, 27);
            this.txtPresentación.TabIndex = 14;
            // 
            // btnCancelarInvent
            // 
            this.btnCancelarInvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCancelarInvent.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnCancelarInvent.Location = new System.Drawing.Point(0, 442);
            this.btnCancelarInvent.Name = "btnCancelarInvent";
            this.btnCancelarInvent.Size = new System.Drawing.Size(661, 35);
            this.btnCancelarInvent.TabIndex = 18;
            this.btnCancelarInvent.Text = "Cancelar ";
            this.btnCancelarInvent.UseVisualStyleBackColor = false;
            this.btnCancelarInvent.Click += new System.EventHandler(this.btnCancelarInvent_Click);
            // 
            // btnConfirmarInvent
            // 
            this.btnConfirmarInvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnConfirmarInvent.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnConfirmarInvent.Location = new System.Drawing.Point(0, 406);
            this.btnConfirmarInvent.Name = "btnConfirmarInvent";
            this.btnConfirmarInvent.Size = new System.Drawing.Size(661, 36);
            this.btnConfirmarInvent.TabIndex = 17;
            this.btnConfirmarInvent.Text = "Confirmar ";
            this.btnConfirmarInvent.UseVisualStyleBackColor = false;
            this.btnConfirmarInvent.Click += new System.EventHandler(this.btnConfirmarInvent_Click);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(193, 141);
            this.textBox1.MaxLength = 3;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(68, 29);
            this.textBox1.TabIndex = 19;
            // 
            // txtConcentración
            // 
            this.txtConcentración.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConcentración.FormattingEnabled = true;
            this.txtConcentración.Items.AddRange(new object[] {
            "g",
            "mg",
            "ml",
            "cc"});
            this.txtConcentración.Location = new System.Drawing.Point(192, 283);
            this.txtConcentración.Name = "txtConcentración";
            this.txtConcentración.Size = new System.Drawing.Size(109, 72);
            this.txtConcentración.TabIndex = 16;
            // 
            // Inventario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(661, 477);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnConfirmarInvent);
            this.Controls.Add(this.btnCancelarInvent);
            this.Controls.Add(this.txtPresentación);
            this.Controls.Add(this.lblPresentación);
            this.Controls.Add(this.txtConcentración);
            this.Controls.Add(this.lblConcentración);
            this.Controls.Add(this.txtFechaVen);
            this.Controls.Add(this.lblFechaVencimiento);
            this.Controls.Add(this.lblCantidadDisponible);
            this.Controls.Add(this.txtCódigoProducto);
            this.Controls.Add(this.lblCódigoProducto);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblNombreProducto);
            this.Controls.Add(this.txtNúmeroEstante);
            this.Controls.Add(this.lblNumeroEstante);
            this.Controls.Add(this.txtFechaRea);
            this.Controls.Add(this.lblFechaRealización);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Berlin Sans FB Demi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Inventario";
            this.Text = "Inventario";
            ((System.ComponentModel.ISupportInitialize)(this.txtNúmeroEstante)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblFechaRealización;
        private System.Windows.Forms.DateTimePicker txtFechaRea;
        private System.Windows.Forms.Label lblNumeroEstante;
        private System.Windows.Forms.NumericUpDown txtNúmeroEstante;
        private System.Windows.Forms.Label lblNombreProducto;
        private System.Windows.Forms.ComboBox txtNombre;
        private System.Windows.Forms.Label lblCódigoProducto;
        private System.Windows.Forms.TextBox txtCódigoProducto;
        private System.Windows.Forms.Label lblCantidadDisponible;
        private System.Windows.Forms.Label lblFechaVencimiento;
        private System.Windows.Forms.DateTimePicker txtFechaVen;
        private System.Windows.Forms.Label lblConcentración;
        private System.Windows.Forms.Label lblPresentación;
        private System.Windows.Forms.ComboBox txtPresentación;
        private System.Windows.Forms.Button btnCancelarInvent;
        private System.Windows.Forms.Button btnConfirmarInvent;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckedListBox txtConcentración;
    }
}