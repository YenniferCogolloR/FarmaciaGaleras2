﻿namespace FARMACIA_GALERAS_2
{
    partial class MenúOpciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenúOpciones));
            this.btnInventario = new System.Windows.Forms.Button();
            this.btnDomicilios = new System.Windows.Forms.Button();
            this.btnSugerenciasyQuejas = new System.Windows.Forms.Button();
            this.btnSalirMenú = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInventario
            // 
            this.btnInventario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnInventario.Font = new System.Drawing.Font("Berlin Sans FB Demi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInventario.Location = new System.Drawing.Point(315, 38);
            this.btnInventario.Name = "btnInventario";
            this.btnInventario.Size = new System.Drawing.Size(168, 79);
            this.btnInventario.TabIndex = 0;
            this.btnInventario.Text = "Inventario";
            this.btnInventario.UseVisualStyleBackColor = false;
            this.btnInventario.Click += new System.EventHandler(this.btnInventario_Click);
            // 
            // btnDomicilios
            // 
            this.btnDomicilios.BackColor = System.Drawing.Color.Magenta;
            this.btnDomicilios.Font = new System.Drawing.Font("Berlin Sans FB Demi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDomicilios.Location = new System.Drawing.Point(315, 145);
            this.btnDomicilios.Name = "btnDomicilios";
            this.btnDomicilios.Size = new System.Drawing.Size(168, 83);
            this.btnDomicilios.TabIndex = 1;
            this.btnDomicilios.Text = "Domicilios";
            this.btnDomicilios.UseVisualStyleBackColor = false;
            this.btnDomicilios.Click += new System.EventHandler(this.btnDomicilios_Click);
            // 
            // btnSugerenciasyQuejas
            // 
            this.btnSugerenciasyQuejas.BackColor = System.Drawing.Color.GreenYellow;
            this.btnSugerenciasyQuejas.Font = new System.Drawing.Font("Berlin Sans FB Demi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSugerenciasyQuejas.Location = new System.Drawing.Point(315, 254);
            this.btnSugerenciasyQuejas.Name = "btnSugerenciasyQuejas";
            this.btnSugerenciasyQuejas.Size = new System.Drawing.Size(168, 75);
            this.btnSugerenciasyQuejas.TabIndex = 2;
            this.btnSugerenciasyQuejas.Text = "Sugerencias y quejas";
            this.btnSugerenciasyQuejas.UseVisualStyleBackColor = false;
            this.btnSugerenciasyQuejas.Click += new System.EventHandler(this.btnSugerenciasyQuejas_Click);
            // 
            // btnSalirMenú
            // 
            this.btnSalirMenú.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSalirMenú.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnSalirMenú.Font = new System.Drawing.Font("Berlin Sans FB Demi", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirMenú.Location = new System.Drawing.Point(0, 366);
            this.btnSalirMenú.Name = "btnSalirMenú";
            this.btnSalirMenú.Size = new System.Drawing.Size(555, 39);
            this.btnSalirMenú.TabIndex = 3;
            this.btnSalirMenú.Text = "Salir ";
            this.btnSalirMenú.UseVisualStyleBackColor = false;
            this.btnSalirMenú.Click += new System.EventHandler(this.btnSalirMenú_Click);
            // 
            // MenúOpciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(555, 405);
            this.Controls.Add(this.btnSalirMenú);
            this.Controls.Add(this.btnSugerenciasyQuejas);
            this.Controls.Add(this.btnDomicilios);
            this.Controls.Add(this.btnInventario);
            this.Name = "MenúOpciones";
            this.Text = "Menú de Opciones";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInventario;
        private System.Windows.Forms.Button btnDomicilios;
        private System.Windows.Forms.Button btnSugerenciasyQuejas;
        private System.Windows.Forms.Button btnSalirMenú;
    }
}