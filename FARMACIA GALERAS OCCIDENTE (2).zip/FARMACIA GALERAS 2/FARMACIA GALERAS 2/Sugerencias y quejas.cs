﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FARMACIA_GALERAS_2
{
    public partial class Sugerencias_y_quejas : Form
    {
        validacionn v = new validacionn();
        public Sugerencias_y_quejas()
        {
            InitializeComponent();
        }

        private void lblEmailSyQ_Click(object sender, EventArgs e)
        {

        }

        private void txtNumDocSyQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }

        private void txtNomSyQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.sololetras(e);
        }

        private void txtTelefonoSyQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"La información ha sido guardada exitosamente");
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ocultar el formulario activo
                         // Mostrar Form1
            MenúOpciones frm = new MenúOpciones();
            frm.Show();
        }
    }
}
