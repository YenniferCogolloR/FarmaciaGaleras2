﻿namespace FARMACIA_GALERAS_2
{
    partial class Usuario_domicilio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Usuario_domicilio));
            this.lblNombreCompUsuario = new System.Windows.Forms.Label();
            this.txtNombreComUsuario = new System.Windows.Forms.TextBox();
            this.lblNumDoc = new System.Windows.Forms.Label();
            this.lblTipoDoc = new System.Windows.Forms.Label();
            this.txtNumDoc = new System.Windows.Forms.TextBox();
            this.txtTipoDoc = new System.Windows.Forms.ComboBox();
            this.lblDirecciónCom = new System.Windows.Forms.Label();
            this.txtDirecciónCom = new System.Windows.Forms.TextBox();
            this.lblBarrio = new System.Windows.Forms.Label();
            this.txtBarrio = new System.Windows.Forms.ComboBox();
            this.lblDomiciliario = new System.Windows.Forms.Label();
            this.txtDomiciliario = new System.Windows.Forms.ComboBox();
            this.lblTelContac = new System.Windows.Forms.Label();
            this.txtTelContac = new System.Windows.Forms.TextBox();
            this.btnConfirmarUsuarioDomi = new System.Windows.Forms.Button();
            this.btnCancelarUsuarioDomi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNombreCompUsuario
            // 
            this.lblNombreCompUsuario.AutoSize = true;
            this.lblNombreCompUsuario.BackColor = System.Drawing.Color.White;
            this.lblNombreCompUsuario.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreCompUsuario.Location = new System.Drawing.Point(27, 41);
            this.lblNombreCompUsuario.Name = "lblNombreCompUsuario";
            this.lblNombreCompUsuario.Size = new System.Drawing.Size(203, 19);
            this.lblNombreCompUsuario.TabIndex = 0;
            this.lblNombreCompUsuario.Text = "Nombres completos usuario";
            // 
            // txtNombreComUsuario
            // 
            this.txtNombreComUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtNombreComUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreComUsuario.Location = new System.Drawing.Point(24, 63);
            this.txtNombreComUsuario.MaxLength = 25;
            this.txtNombreComUsuario.Name = "txtNombreComUsuario";
            this.txtNombreComUsuario.Size = new System.Drawing.Size(186, 27);
            this.txtNombreComUsuario.TabIndex = 1;
            this.txtNombreComUsuario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombreComUsuario_KeyPress);
            // 
            // lblNumDoc
            // 
            this.lblNumDoc.AutoSize = true;
            this.lblNumDoc.BackColor = System.Drawing.Color.White;
            this.lblNumDoc.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumDoc.Location = new System.Drawing.Point(24, 172);
            this.lblNumDoc.Name = "lblNumDoc";
            this.lblNumDoc.Size = new System.Drawing.Size(172, 19);
            this.lblNumDoc.TabIndex = 4;
            this.lblNumDoc.Text = "Número de documento";
            // 
            // lblTipoDoc
            // 
            this.lblTipoDoc.AutoSize = true;
            this.lblTipoDoc.BackColor = System.Drawing.Color.White;
            this.lblTipoDoc.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoDoc.ForeColor = System.Drawing.Color.Black;
            this.lblTipoDoc.Location = new System.Drawing.Point(24, 102);
            this.lblTipoDoc.Name = "lblTipoDoc";
            this.lblTipoDoc.Size = new System.Drawing.Size(146, 19);
            this.lblTipoDoc.TabIndex = 2;
            this.lblTipoDoc.Text = "Tipo de documento";
            // 
            // txtNumDoc
            // 
            this.txtNumDoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtNumDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumDoc.Location = new System.Drawing.Point(25, 194);
            this.txtNumDoc.MaxLength = 10;
            this.txtNumDoc.Name = "txtNumDoc";
            this.txtNumDoc.Size = new System.Drawing.Size(171, 26);
            this.txtNumDoc.TabIndex = 5;
            this.txtNumDoc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumDoc_KeyPress);
            // 
            // txtTipoDoc
            // 
            this.txtTipoDoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtTipoDoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtTipoDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTipoDoc.FormattingEnabled = true;
            this.txtTipoDoc.Items.AddRange(new object[] {
            "Cédula Ciudadania",
            "Tarjeta Identidad",
            "Pasaporte",
            "Cédula extranjera"});
            this.txtTipoDoc.Location = new System.Drawing.Point(24, 124);
            this.txtTipoDoc.Name = "txtTipoDoc";
            this.txtTipoDoc.Size = new System.Drawing.Size(172, 28);
            this.txtTipoDoc.TabIndex = 3;
            // 
            // lblDirecciónCom
            // 
            this.lblDirecciónCom.AutoSize = true;
            this.lblDirecciónCom.BackColor = System.Drawing.Color.White;
            this.lblDirecciónCom.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDirecciónCom.Location = new System.Drawing.Point(27, 239);
            this.lblDirecciónCom.Name = "lblDirecciónCom";
            this.lblDirecciónCom.Size = new System.Drawing.Size(149, 19);
            this.lblDirecciónCom.TabIndex = 6;
            this.lblDirecciónCom.Text = "Dirección Completa";
            // 
            // txtDirecciónCom
            // 
            this.txtDirecciónCom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtDirecciónCom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDirecciónCom.Location = new System.Drawing.Point(24, 261);
            this.txtDirecciónCom.MaxLength = 30;
            this.txtDirecciónCom.Name = "txtDirecciónCom";
            this.txtDirecciónCom.Size = new System.Drawing.Size(174, 27);
            this.txtDirecciónCom.TabIndex = 7;
            // 
            // lblBarrio
            // 
            this.lblBarrio.AutoSize = true;
            this.lblBarrio.BackColor = System.Drawing.Color.White;
            this.lblBarrio.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBarrio.Location = new System.Drawing.Point(27, 304);
            this.lblBarrio.Name = "lblBarrio";
            this.lblBarrio.Size = new System.Drawing.Size(57, 19);
            this.lblBarrio.TabIndex = 8;
            this.lblBarrio.Text = "Barrio ";
            // 
            // txtBarrio
            // 
            this.txtBarrio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtBarrio.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.txtBarrio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarrio.FormattingEnabled = true;
            this.txtBarrio.Location = new System.Drawing.Point(25, 326);
            this.txtBarrio.MaxLength = 25;
            this.txtBarrio.Name = "txtBarrio";
            this.txtBarrio.Size = new System.Drawing.Size(172, 28);
            this.txtBarrio.TabIndex = 9;
            // 
            // lblDomiciliario
            // 
            this.lblDomiciliario.AutoSize = true;
            this.lblDomiciliario.BackColor = System.Drawing.Color.White;
            this.lblDomiciliario.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDomiciliario.Location = new System.Drawing.Point(27, 371);
            this.lblDomiciliario.Name = "lblDomiciliario";
            this.lblDomiciliario.Size = new System.Drawing.Size(99, 19);
            this.lblDomiciliario.TabIndex = 10;
            this.lblDomiciliario.Text = "Domiciliario ";
            // 
            // txtDomiciliario
            // 
            this.txtDomiciliario.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtDomiciliario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtDomiciliario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDomiciliario.FormattingEnabled = true;
            this.txtDomiciliario.Items.AddRange(new object[] {
            "Javier Pedraza",
            "Camilo Gómez",
            "Juan Pablo López",
            "Estevan Mendez"});
            this.txtDomiciliario.Location = new System.Drawing.Point(24, 393);
            this.txtDomiciliario.Name = "txtDomiciliario";
            this.txtDomiciliario.Size = new System.Drawing.Size(174, 28);
            this.txtDomiciliario.TabIndex = 11;
            // 
            // lblTelContac
            // 
            this.lblTelContac.AutoSize = true;
            this.lblTelContac.BackColor = System.Drawing.Color.White;
            this.lblTelContac.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelContac.ForeColor = System.Drawing.Color.Black;
            this.lblTelContac.Location = new System.Drawing.Point(24, 437);
            this.lblTelContac.Name = "lblTelContac";
            this.lblTelContac.Size = new System.Drawing.Size(136, 19);
            this.lblTelContac.TabIndex = 12;
            this.lblTelContac.Text = "Teléfono contacto";
            // 
            // txtTelContac
            // 
            this.txtTelContac.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtTelContac.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelContac.Location = new System.Drawing.Point(24, 459);
            this.txtTelContac.MaxLength = 10;
            this.txtTelContac.Name = "txtTelContac";
            this.txtTelContac.Size = new System.Drawing.Size(172, 27);
            this.txtTelContac.TabIndex = 13;
            this.txtTelContac.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelContac_KeyPress);
            // 
            // btnConfirmarUsuarioDomi
            // 
            this.btnConfirmarUsuarioDomi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnConfirmarUsuarioDomi.Font = new System.Drawing.Font("Berlin Sans FB Demi", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmarUsuarioDomi.Location = new System.Drawing.Point(278, 437);
            this.btnConfirmarUsuarioDomi.Name = "btnConfirmarUsuarioDomi";
            this.btnConfirmarUsuarioDomi.Size = new System.Drawing.Size(316, 40);
            this.btnConfirmarUsuarioDomi.TabIndex = 14;
            this.btnConfirmarUsuarioDomi.Text = "Confirmar ";
            this.btnConfirmarUsuarioDomi.UseVisualStyleBackColor = false;
            this.btnConfirmarUsuarioDomi.Click += new System.EventHandler(this.btnConfirmarUsuarioDomi_Click);
            // 
            // btnCancelarUsuarioDomi
            // 
            this.btnCancelarUsuarioDomi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCancelarUsuarioDomi.Font = new System.Drawing.Font("Berlin Sans FB Demi", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarUsuarioDomi.Location = new System.Drawing.Point(278, 473);
            this.btnCancelarUsuarioDomi.Name = "btnCancelarUsuarioDomi";
            this.btnCancelarUsuarioDomi.Size = new System.Drawing.Size(316, 37);
            this.btnCancelarUsuarioDomi.TabIndex = 15;
            this.btnCancelarUsuarioDomi.Text = "Salir ";
            this.btnCancelarUsuarioDomi.UseVisualStyleBackColor = false;
            this.btnCancelarUsuarioDomi.Click += new System.EventHandler(this.btnCancelarUsuarioDomi_Click);
            // 
            // Usuario_domicilio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(602, 507);
            this.Controls.Add(this.btnCancelarUsuarioDomi);
            this.Controls.Add(this.btnConfirmarUsuarioDomi);
            this.Controls.Add(this.txtTelContac);
            this.Controls.Add(this.lblTelContac);
            this.Controls.Add(this.txtDomiciliario);
            this.Controls.Add(this.lblDomiciliario);
            this.Controls.Add(this.txtBarrio);
            this.Controls.Add(this.lblBarrio);
            this.Controls.Add(this.txtDirecciónCom);
            this.Controls.Add(this.lblDirecciónCom);
            this.Controls.Add(this.txtTipoDoc);
            this.Controls.Add(this.txtNumDoc);
            this.Controls.Add(this.lblTipoDoc);
            this.Controls.Add(this.lblNumDoc);
            this.Controls.Add(this.txtNombreComUsuario);
            this.Controls.Add(this.lblNombreCompUsuario);
            this.Name = "Usuario_domicilio";
            this.Text = "Usuario_domicilio";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNombreCompUsuario;
        private System.Windows.Forms.TextBox txtNombreComUsuario;
        private System.Windows.Forms.Label lblNumDoc;
        private System.Windows.Forms.Label lblTipoDoc;
        private System.Windows.Forms.TextBox txtNumDoc;
        private System.Windows.Forms.ComboBox txtTipoDoc;
        private System.Windows.Forms.Label lblDirecciónCom;
        private System.Windows.Forms.TextBox txtDirecciónCom;
        private System.Windows.Forms.Label lblBarrio;
        private System.Windows.Forms.ComboBox txtBarrio;
        private System.Windows.Forms.Label lblDomiciliario;
        private System.Windows.Forms.ComboBox txtDomiciliario;
        private System.Windows.Forms.Label lblTelContac;
        private System.Windows.Forms.TextBox txtTelContac;
        private System.Windows.Forms.Button btnConfirmarUsuarioDomi;
        private System.Windows.Forms.Button btnCancelarUsuarioDomi;
    }
}