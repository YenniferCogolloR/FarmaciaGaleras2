﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FARMACIA_GALERAS_2
{
    public partial class Usuario_domicilio : Form
    {
        validacionn v = new validacionn();
        public Usuario_domicilio()
        {
            InitializeComponent();
        }

        private void txtNombreComUsuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.sololetras(e);
        }

        private void txtNumDoc_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }

        private void txtTelContac_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }

        private void btnConfirmarUsuarioDomi_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"La información ha sido guardada exitosamente");
        }

        private void btnCancelarUsuarioDomi_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ocultar el formulario activo
                         // Mostrar Form1
            Domicilios frm = new Domicilios();
            frm.Show();
        }
    }
}
