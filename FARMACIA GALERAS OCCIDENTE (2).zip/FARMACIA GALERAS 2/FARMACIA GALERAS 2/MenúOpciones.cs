﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FARMACIA_GALERAS_2
{
    public partial class MenúOpciones : Form
    {
        public MenúOpciones()
        {
            InitializeComponent();
        }

        private void btnInventario_Click(object sender, EventArgs e)
        {
            Inventario inventario = new Inventario();
            inventario.Show();
            Hide();
        }

        private void btnDomicilios_Click(object sender, EventArgs e)
        {
            Domicilios domicilios = new Domicilios();
            domicilios.Show();
            Hide();
        }

        private void btnSugerenciasyQuejas_Click(object sender, EventArgs e)
        {
            Sugerencias_y_quejas sugerenciasyQuejas = new Sugerencias_y_quejas();
            sugerenciasyQuejas.Show();
            Hide();
        }

        private void btnSalirMenú_Click(object sender, EventArgs e)
        {
            Ingreso ingreso= new Ingreso();
             ingreso.Show();
            Hide();
        }
    }
}
