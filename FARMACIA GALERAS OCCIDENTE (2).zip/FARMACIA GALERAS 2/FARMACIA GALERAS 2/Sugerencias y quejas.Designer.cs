﻿namespace FARMACIA_GALERAS_2
{
    partial class Sugerencias_y_quejas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sugerencias_y_quejas));
            this.label1 = new System.Windows.Forms.Label();
            this.lblTipoDocSyQ = new System.Windows.Forms.Label();
            this.lblNomSyQ = new System.Windows.Forms.Label();
            this.txtTipoDocSyQ = new System.Windows.Forms.ComboBox();
            this.txtNumDocSyQ = new System.Windows.Forms.TextBox();
            this.lblNumDocSyQ = new System.Windows.Forms.Label();
            this.txtNomSyQ = new System.Windows.Forms.TextBox();
            this.lblEmailSyQ = new System.Windows.Forms.Label();
            this.lblTelefonoSyQ = new System.Windows.Forms.Label();
            this.txtTelefonoSyQ = new System.Windows.Forms.TextBox();
            this.lblTipoSolicitudSyQ = new System.Windows.Forms.Label();
            this.txtTipoSolicitudSyQ = new System.Windows.Forms.ComboBox();
            this.lblFechaSyQ = new System.Windows.Forms.Label();
            this.txtEmailSyQ = new System.Windows.Forms.TextBox();
            this.txtFechaSyQ = new System.Windows.Forms.DateTimePicker();
            this.lblBarrioSyQ = new System.Windows.Forms.Label();
            this.txtBarrioSyQ = new System.Windows.Forms.ComboBox();
            this.lblDescripciónSyQ = new System.Windows.Forms.Label();
            this.txtDescripciónSyQ = new System.Windows.Forms.TextBox();
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(214, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "SUGERENCIAS Y QUEJAS ";
            // 
            // lblTipoDocSyQ
            // 
            this.lblTipoDocSyQ.AutoSize = true;
            this.lblTipoDocSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblTipoDocSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoDocSyQ.Location = new System.Drawing.Point(319, 38);
            this.lblTipoDocSyQ.Name = "lblTipoDocSyQ";
            this.lblTipoDocSyQ.Size = new System.Drawing.Size(152, 19);
            this.lblTipoDocSyQ.TabIndex = 1;
            this.lblTipoDocSyQ.Text = "Tipo Documento      ";
            // 
            // lblNomSyQ
            // 
            this.lblNomSyQ.AutoSize = true;
            this.lblNomSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNomSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomSyQ.Location = new System.Drawing.Point(316, 102);
            this.lblNomSyQ.Name = "lblNomSyQ";
            this.lblNomSyQ.Size = new System.Drawing.Size(155, 19);
            this.lblNomSyQ.TabIndex = 5;
            this.lblNomSyQ.Text = "Nombres Completos ";
            // 
            // txtTipoDocSyQ
            // 
            this.txtTipoDocSyQ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtTipoDocSyQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTipoDocSyQ.FormattingEnabled = true;
            this.txtTipoDocSyQ.Items.AddRange(new object[] {
            "Cédula Ciudadania",
            "Tarjeta Identidad",
            "Pasaporte",
            "Cédula extranjera"});
            this.txtTipoDocSyQ.Location = new System.Drawing.Point(316, 60);
            this.txtTipoDocSyQ.Name = "txtTipoDocSyQ";
            this.txtTipoDocSyQ.Size = new System.Drawing.Size(155, 28);
            this.txtTipoDocSyQ.TabIndex = 2;
            // 
            // txtNumDocSyQ
            // 
            this.txtNumDocSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumDocSyQ.Location = new System.Drawing.Point(504, 62);
            this.txtNumDocSyQ.MaxLength = 10;
            this.txtNumDocSyQ.Name = "txtNumDocSyQ";
            this.txtNumDocSyQ.Size = new System.Drawing.Size(171, 26);
            this.txtNumDocSyQ.TabIndex = 4;
            this.txtNumDocSyQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumDocSyQ_KeyPress);
            // 
            // lblNumDocSyQ
            // 
            this.lblNumDocSyQ.AutoSize = true;
            this.lblNumDocSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNumDocSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumDocSyQ.Location = new System.Drawing.Point(500, 38);
            this.lblNumDocSyQ.Name = "lblNumDocSyQ";
            this.lblNumDocSyQ.Size = new System.Drawing.Size(175, 19);
            this.lblNumDocSyQ.TabIndex = 3;
            this.lblNumDocSyQ.Text = "Número de Documento";
            // 
            // txtNomSyQ
            // 
            this.txtNomSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomSyQ.Location = new System.Drawing.Point(316, 124);
            this.txtNomSyQ.MaxLength = 25;
            this.txtNomSyQ.Name = "txtNomSyQ";
            this.txtNomSyQ.Size = new System.Drawing.Size(360, 25);
            this.txtNomSyQ.TabIndex = 6;
            this.txtNomSyQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomSyQ_KeyPress);
            // 
            // lblEmailSyQ
            // 
            this.lblEmailSyQ.AutoSize = true;
            this.lblEmailSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblEmailSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailSyQ.Location = new System.Drawing.Point(316, 152);
            this.lblEmailSyQ.Name = "lblEmailSyQ";
            this.lblEmailSyQ.Size = new System.Drawing.Size(49, 19);
            this.lblEmailSyQ.TabIndex = 7;
            this.lblEmailSyQ.Text = "Email";
            this.lblEmailSyQ.Click += new System.EventHandler(this.lblEmailSyQ_Click);
            // 
            // lblTelefonoSyQ
            // 
            this.lblTelefonoSyQ.AutoSize = true;
            this.lblTelefonoSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblTelefonoSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefonoSyQ.Location = new System.Drawing.Point(559, 152);
            this.lblTelefonoSyQ.Name = "lblTelefonoSyQ";
            this.lblTelefonoSyQ.Size = new System.Drawing.Size(70, 19);
            this.lblTelefonoSyQ.TabIndex = 9;
            this.lblTelefonoSyQ.Text = "Teléfono";
            // 
            // txtTelefonoSyQ
            // 
            this.txtTelefonoSyQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefonoSyQ.Location = new System.Drawing.Point(559, 174);
            this.txtTelefonoSyQ.MaxLength = 10;
            this.txtTelefonoSyQ.Name = "txtTelefonoSyQ";
            this.txtTelefonoSyQ.Size = new System.Drawing.Size(117, 26);
            this.txtTelefonoSyQ.TabIndex = 10;
            this.txtTelefonoSyQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefonoSyQ_KeyPress);
            // 
            // lblTipoSolicitudSyQ
            // 
            this.lblTipoSolicitudSyQ.AutoSize = true;
            this.lblTipoSolicitudSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblTipoSolicitudSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoSolicitudSyQ.Location = new System.Drawing.Point(316, 216);
            this.lblTipoSolicitudSyQ.Name = "lblTipoSolicitudSyQ";
            this.lblTipoSolicitudSyQ.Size = new System.Drawing.Size(127, 19);
            this.lblTipoSolicitudSyQ.TabIndex = 11;
            this.lblTipoSolicitudSyQ.Text = "Tipo de solicitud ";
            // 
            // txtTipoSolicitudSyQ
            // 
            this.txtTipoSolicitudSyQ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtTipoSolicitudSyQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTipoSolicitudSyQ.FormattingEnabled = true;
            this.txtTipoSolicitudSyQ.Items.AddRange(new object[] {
            "Sugerencia ",
            "Queja ",
            "Felicitaciones"});
            this.txtTipoSolicitudSyQ.Location = new System.Drawing.Point(316, 238);
            this.txtTipoSolicitudSyQ.Name = "txtTipoSolicitudSyQ";
            this.txtTipoSolicitudSyQ.Size = new System.Drawing.Size(212, 28);
            this.txtTipoSolicitudSyQ.TabIndex = 12;
            // 
            // lblFechaSyQ
            // 
            this.lblFechaSyQ.AutoSize = true;
            this.lblFechaSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblFechaSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaSyQ.Location = new System.Drawing.Point(317, 280);
            this.lblFechaSyQ.Name = "lblFechaSyQ";
            this.lblFechaSyQ.Size = new System.Drawing.Size(55, 19);
            this.lblFechaSyQ.TabIndex = 13;
            this.lblFechaSyQ.Text = "Fecha ";
            // 
            // txtEmailSyQ
            // 
            this.txtEmailSyQ.Location = new System.Drawing.Point(316, 174);
            this.txtEmailSyQ.MaxLength = 30;
            this.txtEmailSyQ.Name = "txtEmailSyQ";
            this.txtEmailSyQ.Size = new System.Drawing.Size(237, 27);
            this.txtEmailSyQ.TabIndex = 8;
            // 
            // txtFechaSyQ
            // 
            this.txtFechaSyQ.CalendarFont = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFechaSyQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFechaSyQ.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtFechaSyQ.Location = new System.Drawing.Point(316, 302);
            this.txtFechaSyQ.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.txtFechaSyQ.Name = "txtFechaSyQ";
            this.txtFechaSyQ.Size = new System.Drawing.Size(212, 26);
            this.txtFechaSyQ.TabIndex = 14;
            // 
            // lblBarrioSyQ
            // 
            this.lblBarrioSyQ.AutoSize = true;
            this.lblBarrioSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblBarrioSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBarrioSyQ.Location = new System.Drawing.Point(319, 342);
            this.lblBarrioSyQ.Name = "lblBarrioSyQ";
            this.lblBarrioSyQ.Size = new System.Drawing.Size(53, 19);
            this.lblBarrioSyQ.TabIndex = 15;
            this.lblBarrioSyQ.Text = "Barrio";
            // 
            // txtBarrioSyQ
            // 
            this.txtBarrioSyQ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.txtBarrioSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarrioSyQ.FormattingEnabled = true;
            this.txtBarrioSyQ.Location = new System.Drawing.Point(316, 364);
            this.txtBarrioSyQ.MaxLength = 25;
            this.txtBarrioSyQ.Name = "txtBarrioSyQ";
            this.txtBarrioSyQ.Size = new System.Drawing.Size(212, 27);
            this.txtBarrioSyQ.TabIndex = 16;
            // 
            // lblDescripciónSyQ
            // 
            this.lblDescripciónSyQ.AutoSize = true;
            this.lblDescripciónSyQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblDescripciónSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescripciónSyQ.Location = new System.Drawing.Point(317, 403);
            this.lblDescripciónSyQ.Name = "lblDescripciónSyQ";
            this.lblDescripciónSyQ.Size = new System.Drawing.Size(90, 19);
            this.lblDescripciónSyQ.TabIndex = 17;
            this.lblDescripciónSyQ.Text = "Descripción";
            // 
            // txtDescripciónSyQ
            // 
            this.txtDescripciónSyQ.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescripciónSyQ.Location = new System.Drawing.Point(316, 425);
            this.txtDescripciónSyQ.MaxLength = 300;
            this.txtDescripciónSyQ.Multiline = true;
            this.txtDescripciónSyQ.Name = "txtDescripciónSyQ";
            this.txtDescripciónSyQ.Size = new System.Drawing.Size(359, 76);
            this.txtDescripciónSyQ.TabIndex = 18;
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnConfirmar.Location = new System.Drawing.Point(67, 414);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(141, 42);
            this.btnConfirmar.TabIndex = 19;
            this.btnConfirmar.Text = "Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = false;
            this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancelar.Location = new System.Drawing.Point(67, 462);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(141, 39);
            this.btnCancelar.TabIndex = 20;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // Sugerencias_y_quejas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(687, 513);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnConfirmar);
            this.Controls.Add(this.txtDescripciónSyQ);
            this.Controls.Add(this.lblDescripciónSyQ);
            this.Controls.Add(this.txtBarrioSyQ);
            this.Controls.Add(this.lblBarrioSyQ);
            this.Controls.Add(this.txtFechaSyQ);
            this.Controls.Add(this.lblFechaSyQ);
            this.Controls.Add(this.txtTipoSolicitudSyQ);
            this.Controls.Add(this.lblTipoSolicitudSyQ);
            this.Controls.Add(this.txtTelefonoSyQ);
            this.Controls.Add(this.lblTelefonoSyQ);
            this.Controls.Add(this.txtEmailSyQ);
            this.Controls.Add(this.lblEmailSyQ);
            this.Controls.Add(this.txtNomSyQ);
            this.Controls.Add(this.lblNumDocSyQ);
            this.Controls.Add(this.txtNumDocSyQ);
            this.Controls.Add(this.txtTipoDocSyQ);
            this.Controls.Add(this.lblNomSyQ);
            this.Controls.Add(this.lblTipoDocSyQ);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Berlin Sans FB Demi", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Sugerencias_y_quejas";
            this.Text = "Sugerencias_y_quejas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTipoDocSyQ;
        private System.Windows.Forms.Label lblNomSyQ;
        private System.Windows.Forms.ComboBox txtTipoDocSyQ;
        private System.Windows.Forms.TextBox txtNumDocSyQ;
        private System.Windows.Forms.Label lblNumDocSyQ;
        private System.Windows.Forms.TextBox txtNomSyQ;
        private System.Windows.Forms.Label lblEmailSyQ;
        private System.Windows.Forms.Label lblTelefonoSyQ;
        private System.Windows.Forms.TextBox txtTelefonoSyQ;
        private System.Windows.Forms.Label lblTipoSolicitudSyQ;
        private System.Windows.Forms.ComboBox txtTipoSolicitudSyQ;
        private System.Windows.Forms.Label lblFechaSyQ;
        private System.Windows.Forms.TextBox txtEmailSyQ;
        private System.Windows.Forms.DateTimePicker txtFechaSyQ;
        private System.Windows.Forms.Label lblBarrioSyQ;
        private System.Windows.Forms.ComboBox txtBarrioSyQ;
        private System.Windows.Forms.Label lblDescripciónSyQ;
        private System.Windows.Forms.TextBox txtDescripciónSyQ;
        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.Button btnCancelar;
    }
}