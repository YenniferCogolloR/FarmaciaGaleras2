﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FARMACIA_GALERAS_2
{
    public partial class Inventario : Form
    {
        validacionn v = new validacionn();
        public Inventario()
        {
            InitializeComponent();
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.sololetras(e);
        }

        private void txtCódigoProducto_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void txtcodProduc_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }

        private void btnCancelarInvent_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ocultar el formulario activo
                         // Mostrar Form1
            MenúOpciones frm = new MenúOpciones();
            frm.Show();
        }

        private void btnConfirmarInvent_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"La información ha sido guardada de manera exitosa");
        }
    }
}
