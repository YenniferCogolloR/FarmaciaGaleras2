﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FARMACIA_GALERAS_2
{
    public partial class Ingreso : Form
    {
        validacionn v = new validacionn();
        public Ingreso()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtContraseña_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void txtContraseña_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnSalirIngreso_Click(object sender, EventArgs e)
        {
            Close();
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ocultar el formulario activo
                         // Mostrar Form1
            MenúOpciones frm = new MenúOpciones();
            frm.Show();
        }

        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUsuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            v.solonumeros(e);
        }
    }
}
