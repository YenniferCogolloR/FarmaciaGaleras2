﻿namespace FARMACIA_GALERAS_2
{
    partial class Domicilios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Domicilios));
            this.label1 = new System.Windows.Forms.Label();
            this.lblNombreProducto = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCancelarDomi = new System.Windows.Forms.Button();
            this.btnConfirmarDomi = new System.Windows.Forms.Button();
            this.txtNombreProducto = new System.Windows.Forms.TextBox();
            this.lblCódigoProducto = new System.Windows.Forms.Label();
            this.txtCódigoProducto = new System.Windows.Forms.TextBox();
            this.lblConcentración = new System.Windows.Forms.Label();
            this.lblPresentación = new System.Windows.Forms.Label();
            this.txtPresentación = new System.Windows.Forms.ComboBox();
            this.txtConcentración = new System.Windows.Forms.ComboBox();
            this.lblValorUnitario = new System.Windows.Forms.Label();
            this.txtValorUnitario = new System.Windows.Forms.TextBox();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.txtcantidad = new System.Windows.Forms.NumericUpDown();
            this.lblValorTotal = new System.Windows.Forms.Label();
            this.txtValorTotal = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcantidad)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(85, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(351, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "ÁREA DOMICILIOS GALERAS OCCIDENTE ";
            // 
            // lblNombreProducto
            // 
            this.lblNombreProducto.AutoSize = true;
            this.lblNombreProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblNombreProducto.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreProducto.Location = new System.Drawing.Point(12, 64);
            this.lblNombreProducto.Name = "lblNombreProducto";
            this.lblNombreProducto.Size = new System.Drawing.Size(141, 19);
            this.lblNombreProducto.TabIndex = 1;
            this.lblNombreProducto.Text = "Nombre Producto ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 300);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(273, 203);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // btnCancelarDomi
            // 
            this.btnCancelarDomi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCancelarDomi.Location = new System.Drawing.Point(271, 468);
            this.btnCancelarDomi.Name = "btnCancelarDomi";
            this.btnCancelarDomi.Size = new System.Drawing.Size(400, 35);
            this.btnCancelarDomi.TabIndex = 16;
            this.btnCancelarDomi.Text = "Cancelar";
            this.btnCancelarDomi.UseVisualStyleBackColor = false;
            this.btnCancelarDomi.Click += new System.EventHandler(this.btnCancelarDomi_Click);
            // 
            // btnConfirmarDomi
            // 
            this.btnConfirmarDomi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnConfirmarDomi.Location = new System.Drawing.Point(271, 437);
            this.btnConfirmarDomi.Name = "btnConfirmarDomi";
            this.btnConfirmarDomi.Size = new System.Drawing.Size(400, 36);
            this.btnConfirmarDomi.TabIndex = 15;
            this.btnConfirmarDomi.Text = "Confirmar";
            this.btnConfirmarDomi.UseVisualStyleBackColor = false;
            this.btnConfirmarDomi.Click += new System.EventHandler(this.btnConfirmarDomi_Click);
            // 
            // txtNombreProducto
            // 
            this.txtNombreProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtNombreProducto.Location = new System.Drawing.Point(159, 60);
            this.txtNombreProducto.MaxLength = 25;
            this.txtNombreProducto.Name = "txtNombreProducto";
            this.txtNombreProducto.Size = new System.Drawing.Size(214, 26);
            this.txtNombreProducto.TabIndex = 2;
            this.txtNombreProducto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombreProducto_KeyPress);
            // 
            // lblCódigoProducto
            // 
            this.lblCódigoProducto.AutoSize = true;
            this.lblCódigoProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblCódigoProducto.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCódigoProducto.Location = new System.Drawing.Point(396, 62);
            this.lblCódigoProducto.Name = "lblCódigoProducto";
            this.lblCódigoProducto.Size = new System.Drawing.Size(133, 19);
            this.lblCódigoProducto.TabIndex = 3;
            this.lblCódigoProducto.Text = "Código Producto ";
            this.lblCódigoProducto.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtCódigoProducto
            // 
            this.txtCódigoProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCódigoProducto.Font = new System.Drawing.Font("Berlin Sans FB Demi", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCódigoProducto.Location = new System.Drawing.Point(535, 59);
            this.txtCódigoProducto.MaxLength = 6;
            this.txtCódigoProducto.Name = "txtCódigoProducto";
            this.txtCódigoProducto.Size = new System.Drawing.Size(100, 27);
            this.txtCódigoProducto.TabIndex = 4;
            this.txtCódigoProducto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCódigoProducto_KeyPress);
            // 
            // lblConcentración
            // 
            this.lblConcentración.AutoSize = true;
            this.lblConcentración.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblConcentración.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConcentración.Location = new System.Drawing.Point(418, 99);
            this.lblConcentración.Name = "lblConcentración";
            this.lblConcentración.Size = new System.Drawing.Size(111, 19);
            this.lblConcentración.TabIndex = 7;
            this.lblConcentración.Text = "Concentración";
            // 
            // lblPresentación
            // 
            this.lblPresentación.AutoSize = true;
            this.lblPresentación.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblPresentación.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPresentación.Location = new System.Drawing.Point(53, 106);
            this.lblPresentación.Name = "lblPresentación";
            this.lblPresentación.Size = new System.Drawing.Size(100, 19);
            this.lblPresentación.TabIndex = 5;
            this.lblPresentación.Text = "Presentación";
            // 
            // txtPresentación
            // 
            this.txtPresentación.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtPresentación.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtPresentación.ForeColor = System.Drawing.Color.Black;
            this.txtPresentación.FormattingEnabled = true;
            this.txtPresentación.Items.AddRange(new object[] {
            "Capsulas",
            "Comprimidos",
            "Solubles",
            "Stick pack",
            "Jarabes",
            "Ampollas "});
            this.txtPresentación.Location = new System.Drawing.Point(159, 99);
            this.txtPresentación.Name = "txtPresentación";
            this.txtPresentación.Size = new System.Drawing.Size(121, 26);
            this.txtPresentación.TabIndex = 6;
            // 
            // txtConcentración
            // 
            this.txtConcentración.BackColor = System.Drawing.Color.Silver;
            this.txtConcentración.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtConcentración.FormattingEnabled = true;
            this.txtConcentración.Items.AddRange(new object[] {
            "g",
            "mg",
            "ml",
            "cc"});
            this.txtConcentración.Location = new System.Drawing.Point(558, 92);
            this.txtConcentración.Name = "txtConcentración";
            this.txtConcentración.Size = new System.Drawing.Size(59, 26);
            this.txtConcentración.TabIndex = 8;
            // 
            // lblValorUnitario
            // 
            this.lblValorUnitario.AutoSize = true;
            this.lblValorUnitario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblValorUnitario.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorUnitario.Location = new System.Drawing.Point(43, 163);
            this.lblValorUnitario.Name = "lblValorUnitario";
            this.lblValorUnitario.Size = new System.Drawing.Size(110, 19);
            this.lblValorUnitario.TabIndex = 9;
            this.lblValorUnitario.Text = "Valor Unitario";
            // 
            // txtValorUnitario
            // 
            this.txtValorUnitario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtValorUnitario.Location = new System.Drawing.Point(159, 156);
            this.txtValorUnitario.MaxLength = 6;
            this.txtValorUnitario.Name = "txtValorUnitario";
            this.txtValorUnitario.Size = new System.Drawing.Size(121, 26);
            this.txtValorUnitario.TabIndex = 10;
            this.txtValorUnitario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValorUnitario_KeyPress);
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblCantidad.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantidad.Location = new System.Drawing.Point(451, 136);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(78, 19);
            this.lblCantidad.TabIndex = 11;
            this.lblCantidad.Text = "Cantidad ";
            // 
            // txtcantidad
            // 
            this.txtcantidad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtcantidad.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcantidad.Location = new System.Drawing.Point(558, 129);
            this.txtcantidad.Name = "txtcantidad";
            this.txtcantidad.Size = new System.Drawing.Size(48, 26);
            this.txtcantidad.TabIndex = 12;
            // 
            // lblValorTotal
            // 
            this.lblValorTotal.AutoSize = true;
            this.lblValorTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblValorTotal.Font = new System.Drawing.Font("Berlin Sans FB", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorTotal.Location = new System.Drawing.Point(53, 221);
            this.lblValorTotal.Name = "lblValorTotal";
            this.lblValorTotal.Size = new System.Drawing.Size(89, 19);
            this.lblValorTotal.TabIndex = 13;
            this.lblValorTotal.Text = "Valor Total";
            // 
            // txtValorTotal
            // 
            this.txtValorTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtValorTotal.Location = new System.Drawing.Point(159, 214);
            this.txtValorTotal.MaxLength = 6;
            this.txtValorTotal.Name = "txtValorTotal";
            this.txtValorTotal.Size = new System.Drawing.Size(121, 26);
            this.txtValorTotal.TabIndex = 14;
            this.txtValorTotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValorTotal_KeyPress);
            // 
            // Domicilios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(669, 502);
            this.Controls.Add(this.txtValorTotal);
            this.Controls.Add(this.lblValorTotal);
            this.Controls.Add(this.txtcantidad);
            this.Controls.Add(this.lblCantidad);
            this.Controls.Add(this.txtValorUnitario);
            this.Controls.Add(this.lblValorUnitario);
            this.Controls.Add(this.txtConcentración);
            this.Controls.Add(this.txtPresentación);
            this.Controls.Add(this.lblPresentación);
            this.Controls.Add(this.lblConcentración);
            this.Controls.Add(this.txtCódigoProducto);
            this.Controls.Add(this.lblCódigoProducto);
            this.Controls.Add(this.txtNombreProducto);
            this.Controls.Add(this.btnConfirmarDomi);
            this.Controls.Add(this.btnCancelarDomi);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblNombreProducto);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Berlin Sans FB Demi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Domicilios";
            this.Text = "Domicilios";
            this.Load += new System.EventHandler(this.Domicilios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcantidad)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNombreProducto;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnCancelarDomi;
        private System.Windows.Forms.Button btnConfirmarDomi;
        private System.Windows.Forms.TextBox txtNombreProducto;
        private System.Windows.Forms.Label lblCódigoProducto;
        private System.Windows.Forms.TextBox txtCódigoProducto;
        private System.Windows.Forms.Label lblConcentración;
        private System.Windows.Forms.Label lblPresentación;
        private System.Windows.Forms.ComboBox txtPresentación;
        private System.Windows.Forms.ComboBox txtConcentración;
        private System.Windows.Forms.Label lblValorUnitario;
        private System.Windows.Forms.TextBox txtValorUnitario;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.NumericUpDown txtcantidad;
        private System.Windows.Forms.Label lblValorTotal;
        private System.Windows.Forms.TextBox txtValorTotal;
    }
}